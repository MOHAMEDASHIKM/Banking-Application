// import Nav2 from "./nav";
// import{HashRouter,Routes,Route} from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Create from "./create";



// export default function App(){

//     return(
//         <>
//         <HashRouter>
//         <Nav2 />
//         <Routes>
//             <Route path='/Create' element =  {<Create />} />
//         </Routes>
//         </HashRouter>
//         </>
//     )
// }


//  bad bank program===================================================

import Nav2 from "./nav";
import{HashRouter,Routes,Route} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Create from "./create";
import Deposit from "./deposit";
import Withdraw from "./withdraw";
import Alldata from "./alldata";
import userContext from "./context";
import Home from "./home";


export default function App(){

    return(
        <>
        <HashRouter>
            <userContext.Provider value={
                {users:
                [{Name:"Ashi",
                 Email:"ashi123@gmail.com",
                 Password:"1234567890",
                 Balance:0}]
                 }}>
        <Nav2 />
        <Routes>
            <Route path='/Home' element =  {<Home />} />
            <Route path='/Create' element =  {<Create />} />
            <Route path='/Deposit' element =  {<Deposit />} />
            <Route path='/Withdraw' element =  {<Withdraw />} />
            <Route path='/Alldata' element =  {<Alldata />} />

        </Routes>
        </userContext.Provider>
        </HashRouter>
                 
        </>
    )
}