
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';



export default function Nav2(){
    return(
        <>
        {/* nav bar from bootstap */}

    <Navbar bg="light" expand="lg">
      <Container fluid>
        <Navbar.Brand href="#/Home"><h3>BAD BANK</h3></Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          > 
            <Nav.Link href="#/Create">Create</Nav.Link>
            <Nav.Link href="#/Deposit">Deposit</Nav.Link>
            <Nav.Link href="#/Withdraw">Withdraw</Nav.Link>
            <Nav.Link href="#/Alldata">AllData</Nav.Link>
          </Nav>
          <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>       
        
        </>
    );
}